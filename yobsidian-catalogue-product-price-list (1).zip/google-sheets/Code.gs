const API_KEY = 'CHANGE_THIS_TO_YOUR_PRIVATE_KEY';

const SCHEMAS = {
  orders: ['id','created','date','customer','phone','product','quantity','amount','status','paymentStatus','amountPaid','deliveryDate','deliveryMethod','trackingNumber','address','notes'],
  expenses: ['id','date','paidBy','category','description','amount'],
  products: ['id','name','category','size','material','colour','printingCost','packagingCost','otherCost','price','notes'],
  inventory: ['id','updated','type','name','size','material','quantity','minimum','unit','location','notes']
};

function doGet(e) {
  try {
    checkKey_(e.parameter.key);
    const result = {};
    Object.keys(SCHEMAS).forEach(type => result[type] = readRecords_(type));
    return json_({ok:true, data:result});
  } catch (error) {
    return json_({ok:false, error:error.message});
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    checkKey_(body.key);
    if (!SCHEMAS[body.type]) throw new Error('Unknown record type');
    if (body.action === 'upsert') upsert_(body.type, body.record);
    else if (body.action === 'delete') delete_(body.type, body.id);
    else if (body.action === 'replaceAll') replaceAll_(body.type, body.records || []);
    else throw new Error('Unknown action');
    return json_({ok:true});
  } catch (error) {
    return json_({ok:false, error:error.message});
  }
}

function checkKey_(key) {
  if (!key || key !== API_KEY) throw new Error('Not authorized');
}

function sheet_(type) {
  const name = type.charAt(0).toUpperCase() + type.slice(1);
  const file = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = file.getSheetByName(name);
  if (!sheet) sheet = file.insertSheet(name);
  const headers = SCHEMAS[type];
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,headers.length).setFontWeight('bold').setBackground('#1a1713').setFontColor('#e5cfa5');
  }
  return sheet;
}

function readRecords_(type) {
  const sheet = sheet_(type), headers = SCHEMAS[type];
  if (sheet.getLastRow() < 2) return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues().filter(row => row[0] !== '').map(row => {
    const record = {};
    headers.forEach((key,index) => record[key] = row[index]);
    return record;
  });
}

function upsert_(type, record) {
  if (!record || record.id === undefined) throw new Error('Record ID is required');
  const lock = LockService.getDocumentLock();
  lock.waitLock(10000);
  try {
    const sheet = sheet_(type), headers = SCHEMAS[type];
    const row = headers.map(key => record[key] === undefined ? '' : record[key]);
    const ids = sheet.getLastRow() < 2 ? [] : sheet.getRange(2,1,sheet.getLastRow()-1,1).getValues().flat().map(String);
    const index = ids.indexOf(String(record.id));
    if (index >= 0) sheet.getRange(index+2,1,1,headers.length).setValues([row]);
    else sheet.appendRow(row);
  } finally { lock.releaseLock(); }
}

function delete_(type, id) {
  const sheet = sheet_(type);
  if (sheet.getLastRow() < 2) return;
  const ids = sheet.getRange(2,1,sheet.getLastRow()-1,1).getValues().flat().map(String);
  const index = ids.indexOf(String(id));
  if (index >= 0) sheet.deleteRow(index+2);
}

function replaceAll_(type, records) {
  const sheet = sheet_(type), headers = SCHEMAS[type];
  if (sheet.getLastRow() > 1) sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).clearContent();
  if (records.length) sheet.getRange(2,1,records.length,headers.length).setValues(records.map(record => headers.map(key => record[key] === undefined ? '' : record[key])));
}

function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
